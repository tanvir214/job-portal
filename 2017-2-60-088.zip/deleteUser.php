<?php
    
    session_start();
    include 'conn.php';

    $userId=$_GET['userId'];
    $table=$_GET['tableName'];

    $sql = "DELETE FROM $table WHERE user_name='$userId'";
    echo $sql;


    if(mysqli_query($conn,$sql)){
        $_SESSION['status']="Delete Successfully";
        header('location:admindash.php');
    }

    echo $table;

?>